/**
 * RestTimer
 *
 * Overlay FULLSCREEN de descanso entre blocos.
 * Aparece após a conclusão de cada bloco (se restSeconds > 0).
 *
 * DIFERENÇA do timer inline do ClusterInput:
 *   Este é fullscreen — substitui visualmente a tela inteira.
 *   O do ClusterInput é pequeno e fica dentro do card.
 *
 * ANIMAÇÃO:
 *   Círculo SVG com stroke-dashoffset que incrementa conforme o tempo passa.
 *   O círculo começa cheio e vai "esvaziando" até completar.
 *
 *   Circunferência = 2 * π * raio = 2 * π * 52 ≈ 326.7
 *   stroke-dashoffset = 326.7 * (elapsed / total)
 *
 * COMPORTAMENTO:
 *   - Não pausa se o app for para background (continua pelo clock real)
 *   - Vibra o dispositivo ao terminar (se permitido)
 *   - "Pular descanso" chama onSkip imediatamente
 */

import React, { useState, useEffect, useRef } from "react";

const CIRCUMFERENCE = 2 * Math.PI * 52; // ≈ 326.7

export default function RestTimer({ seconds, onComplete, onSkip }) {
  const [remaining, setRemaining] = useState(seconds);
  const startTimeRef = useRef(Date.now());
  const rafRef = useRef(null);

  useEffect(() => {
    // Usa requestAnimationFrame + clock real para não depender de setInterval preciso
    // Isso garante que o timer continue correto mesmo após o app voltar do background
    function tick() {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      const rem = Math.max(0, seconds - elapsed);
      setRemaining(rem);

      if (rem <= 0) {
        // Vibração ao terminar
        if (navigator.vibrate) navigator.vibrate(200);
        setTimeout(onComplete, 300); // pequeno delay para o aluno ver o "0"
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [seconds, onComplete]);

  const progress = (seconds - remaining) / seconds;
  const dashOffset = CIRCUMFERENCE * progress;

  return (
    <div className="rest-timer-overlay">
      <div className="rest-timer__label">Descanso</div>

      {/* Círculo SVG animado */}
      <svg
        className="rest-timer__ring"
        width="140"
        height="140"
        viewBox="0 0 140 140"
        aria-hidden="true"
      >
        {/* Track (fundo) */}
        <circle
          cx="70"
          cy="70"
          r="52"
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="4"
        />
        {/* Progresso — começa no topo (-90deg) */}
        <circle
          cx="70"
          cy="70"
          r="52"
          fill="none"
          stroke="#c8ff00"
          strokeWidth="4"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          transform="rotate(-90 70 70)"
          style={{ transition: "stroke-dashoffset 0.9s linear" }}
        />
      </svg>

      {/* Countdown numérico */}
      <div className="rest-timer__number">{remaining}</div>
      <div className="rest-timer__sub">segundos de descanso</div>

      {/* Skip */}
      <button
        className="rest-timer__skip"
        onClick={onSkip}
      >
        Pular descanso
      </button>
    </div>
  );
}
