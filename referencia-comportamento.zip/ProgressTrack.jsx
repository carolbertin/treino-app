/**
 * ProgressTrack
 *
 * Barra de progresso segmentada no topo da tela.
 * Um segmento por bloco do exercício.
 *
 * Estados por segmento:
 *   done    → cor accent (#c8ff00), opacidade 100%
 *   active  → cor accent, opacidade 40%
 *   pending → cinza claro, opacidade 10%
 */

import React from "react";

export default function ProgressTrack({ total, completed, active }) {
  return (
    <div className="progress-track" role="progressbar" aria-valuenow={completed} aria-valuemax={total}>
      {Array.from({ length: total }, (_, i) => {
        const isDone = i < completed;
        const isActive = i === active && !isDone;

        return (
          <div
            key={i}
            className={[
              "progress-track__seg",
              isDone && "progress-track__seg--done",
              isActive && "progress-track__seg--active",
            ]
              .filter(Boolean)
              .join(" ")}
          />
        );
      })}
    </div>
  );
}
