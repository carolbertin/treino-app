/**
 * ExerciseScreen
 *
 * Tela principal de execução de exercício pelo aluno.
 * Orquestra o fluxo de blocos, timers e salvamento.
 *
 * ESTADO GLOBAL:
 *   loading → ready → executing → resting → completed → saving → saved
 *
 * PRINCÍPIO: revelação progressiva.
 * O aluno vê apenas o bloco ativo. Anteriores colapsam. Próximos ficam em preview.
 */

import React, { useState, useCallback } from "react";
import { translateTechnique } from "../utils/techniqueTranslator";
import { getActionLabel } from "../utils/actionButtonLabel";
import BlockCard from "./BlockCard";
import RestTimer from "./RestTimer";
import ProgressTrack from "./ProgressTrack";

// ---------------------------------------------------------------------------
// Dados de exemplo — substituir por props / fetch real
// ---------------------------------------------------------------------------
const MOCK_EXERCISE = {
  name: "Cadeira flexora",
  position: 2,
  total: 5,
  lastRecord: { weight: 50, reps: 10, date: "11/05" },
  blocks: [
    {
      id: "b1",
      technique: "feeder_set",
      series: 2,
      repsTarget: 10,
      rir: 2,
      restSeconds: 60,
    },
    {
      id: "b2",
      technique: "work_set",
      series: 1,
      repsTarget: 8,
      rir: 0,
      restSeconds: 90,
    },
    {
      id: "b3",
      technique: "cluster_set",
      clusterBlocks: 3,
      repsPerCluster: 4,
      restBetweenClusters: 7,
      restSeconds: 0,
    },
  ],
};

// ---------------------------------------------------------------------------
// Componente principal
// ---------------------------------------------------------------------------
export default function ExerciseScreen({ exercise = MOCK_EXERCISE, onSave, onBack }) {
  const [screenState, setScreenState] = useState("ready");
  // blockStates: array de 'upcoming' | 'active' | 'done' — um por bloco
  const [blockStates, setBlockStates] = useState(() =>
    exercise.blocks.map((_, i) => (i === 0 ? "active" : "upcoming"))
  );
  // blockRecords: dados registrados pelo aluno por bloco
  const [blockRecords, setBlockRecords] = useState(
    () => exercise.blocks.map(() => null)
  );
  const [activeBlockIndex, setActiveBlockIndex] = useState(0);
  const [timerSeconds, setTimerSeconds] = useState(0);

  // Chamado quando o aluno conclui um bloco
  const handleBlockComplete = useCallback(
    (blockIndex, record) => {
      // Salva o registro do bloco
      setBlockRecords((prev) => {
        const next = [...prev];
        next[blockIndex] = record;
        return next;
      });

      // Marca bloco como done
      setBlockStates((prev) => {
        const next = [...prev];
        next[blockIndex] = "done";
        return next;
      });

      const isLastBlock = blockIndex === exercise.blocks.length - 1;

      if (isLastBlock) {
        setScreenState("completed");
        return;
      }

      const restSecs = exercise.blocks[blockIndex].restSeconds || 0;

      if (restSecs > 0) {
        // Inicia timer de descanso antes de abrir próximo bloco
        setTimerSeconds(restSecs);
        setScreenState("resting");
      } else {
        activateNextBlock(blockIndex);
      }
    },
    [exercise.blocks]
  );

  // Ativa o próximo bloco após descanso ou diretamente
  const activateNextBlock = useCallback(
    (currentIndex) => {
      const nextIndex = currentIndex + 1;
      setActiveBlockIndex(nextIndex);
      setBlockStates((prev) => {
        const next = [...prev];
        next[nextIndex] = "active";
        return next;
      });
      setScreenState("executing");
    },
    []
  );

  const handleTimerComplete = useCallback(() => {
    activateNextBlock(activeBlockIndex);
  }, [activeBlockIndex, activateNextBlock]);

  const handleTimerSkip = useCallback(() => {
    activateNextBlock(activeBlockIndex);
  }, [activeBlockIndex, activateNextBlock]);

  const handleSave = useCallback(async () => {
    setScreenState("saving");
    try {
      await onSave?.({ exercise, blockRecords });
      setScreenState("saved");
    } catch {
      setScreenState("completed"); // volta para tentar novamente
    }
  }, [exercise, blockRecords, onSave]);

  const isCompleted = screenState === "completed" || screenState === "saving" || screenState === "saved";
  const completedCount = blockStates.filter((s) => s === "done").length;

  return (
    <div className="exercise-screen">
      {/* ── Top bar ── */}
      <div className="top-bar">
        <button className="back-btn" onClick={onBack}>
          ← Treino
        </button>
        <span className="ex-name">{exercise.name}</span>
        <span className="ex-position">
          {exercise.position} de {exercise.total}
        </span>
      </div>

      {/* ── Referência do último registro ── */}
      {exercise.lastRecord && (
        <div className="last-ref">
          <span className="last-ref__label">ÚLTIMO</span>
          <span className="last-ref__divider" />
          <span className="last-ref__value">
            {exercise.lastRecord.weight} kg · {exercise.lastRecord.reps} reps ·{" "}
            {exercise.lastRecord.date}
          </span>
        </div>
      )}

      {/* ── Progresso segmentado (um segmento por bloco) ── */}
      {exercise.blocks.length > 1 && (
        <ProgressTrack
          total={exercise.blocks.length}
          completed={completedCount}
          active={activeBlockIndex}
        />
      )}

      {/* ── Blocos ── */}
      <div className="block-list">
        {exercise.blocks.map((block, index) => (
          <BlockCard
            key={block.id}
            block={block}
            state={blockStates[index]}
            record={blockRecords[index]}
            index={index}
            total={exercise.blocks.length}
            onComplete={(record) => handleBlockComplete(index, record)}
          />
        ))}
      </div>

      {/* ── Action bar sticky ── */}
      <div className="action-bar">
        {isCompleted ? (
          <button
            className={`action-btn ${screenState === "saving" ? "action-btn--loading" : ""}`}
            onClick={handleSave}
            disabled={screenState === "saving" || screenState === "saved"}
          >
            {screenState === "saving" ? "Salvando…" : screenState === "saved" ? "Salvo!" : "Salvar exercício"}
          </button>
        ) : (
          // O botão da action bar é controlado pelo BlockCard ativo via context/callback
          // Aqui fica vazio — o BlockCard renderiza seu próprio botão ou usa portal
          null
        )}
      </div>

      {/* ── Timer de descanso (overlay fullscreen) ── */}
      {screenState === "resting" && (
        <RestTimer
          seconds={timerSeconds}
          onComplete={handleTimerComplete}
          onSkip={handleTimerSkip}
        />
      )}
    </div>
  );
}
