/**
 * techniqueTranslator
 *
 * Converte a configuração técnica do professor (ex: "cluster_set", "rir: 2")
 * na linguagem de ação do aluno (ex: "Aquecimento", "pare com 2 sobrando").
 *
 * O professor configura técnicas no painel dele.
 * Esta função é a camada de tradução — só existe na apresentação.
 * Nada no banco ou na lógica de negócio deve mudar.
 *
 * Retorna:
 *   title        — nome do bloco para o aluno
 *   subtitle     — detalhe operacional (quantas séries, como parar)
 *   hint         — instrução de ação contextual (aparece na hint box)
 *   preview      — texto curto para o bloco "upcoming"
 *   badge        — label do badge colorido
 *   badgeVariant — 'warm' | 'main' | 'cluster' | 'backoff' (controla a cor do badge)
 *   technique    — técnica original (para lógica condicional no BlockCard)
 */

export function translateTechnique(block) {
  switch (block.technique) {
    case "feeder_set":
      return {
        title: "Aquecimento",
        subtitle: `${block.series} ${block.series > 1 ? "séries" : "série"} · pare com ${block.rir} sobrando`,
        hint: `Série leve de aquecimento. Pare enquanto ainda está fácil — você conseguiria mais ${block.rir} facilmente.`,
        preview: `Aquecimento · ${block.series} séries`,
        badge: "Aquecimento",
        badgeVariant: "warm",
        technique: "feeder_set",
      };

    case "work_set":
      if (block.rir && block.rir > 0) {
        return {
          title: "Série principal",
          subtitle: `${block.series} ${block.series > 1 ? "séries" : "série"} · pare com ${block.rir} sobrando`,
          hint: `Esforce-se bastante, mas pare enquanto ainda conseguiria mais ${block.rir} repetições.`,
          preview: `Série principal · ${block.series} série${block.series > 1 ? "s" : ""} de ${block.repsTarget} reps`,
          badge: "Principal",
          badgeVariant: "main",
          technique: "work_set",
        };
      }
      return {
        title: "Série principal",
        subtitle: `${block.series} ${block.series > 1 ? "séries" : "série"} · vá até o limite`,
        hint: "Empurre com tudo. Pare só quando não conseguir mais uma repetição completa.",
        preview: `Série principal · ${block.series} série${block.series > 1 ? "s" : ""} de ${block.repsTarget} reps`,
        badge: "Principal",
        badgeVariant: "main",
        technique: "work_set",
      };

    case "cluster_set":
      return {
        title: "Mini-séries em sequência",
        subtitle: `${block.clusterBlocks} × ${block.repsPerCluster} reps · ${block.restBetweenClusters}s de descanso entre elas`,
        hint: `Faça ${block.repsPerCluster} reps, descanse ${block.restBetweenClusters} segundos, repita. Mesmo peso nas ${block.clusterBlocks} mini-séries.`,
        preview: `Cluster · ${block.clusterBlocks} × ${block.repsPerCluster} reps`,
        badge: "Cluster",
        badgeVariant: "cluster",
        technique: "cluster_set",
      };

    case "back_off":
      return {
        title: "Série de alívio",
        subtitle: `${block.series} ${block.series > 1 ? "séries" : "série"} · ${block.dropPercent ?? 20}% menos peso`,
        hint: `Reduza o peso em ${block.dropPercent ?? 20}%. O esforço continua alto — mais reps, menos carga.`,
        preview: `Série de alívio · ${block.series} série${block.series > 1 ? "s" : ""}`,
        badge: "Alívio",
        badgeVariant: "backoff",
        technique: "back_off",
      };

    case "rest_pause":
      return {
        title: "Série contínua com pausa",
        subtitle: `Vá até falhar · descanse ${block.pauseSeconds ?? 15}s · continue`,
        hint: `Vá até quase falhar. Descanse ${block.pauseSeconds ?? 15}s respirando fundo. Continue sem mudar o peso.`,
        preview: "Série com pausa · vá até o limite",
        badge: "Rest-pause",
        badgeVariant: "main",
        technique: "rest_pause",
      };

    case "drop_set":
      return {
        title: "Série com redução de peso",
        subtitle: `Vá até falhar · reduza ${block.dropPercent ?? 20}% · continue`,
        hint: `Vá até falhar, reduza o peso em ${block.dropPercent ?? 20}% imediatamente e continue sem descanso.`,
        preview: "Drop set · redução de peso",
        badge: "Drop set",
        badgeVariant: "warm",
        technique: "drop_set",
      };

    default:
      return {
        title: block.technique ?? "Série",
        subtitle: `${block.series ?? 1} série`,
        hint: null,
        preview: `${block.series ?? 1} série`,
        badge: "Série",
        badgeVariant: "main",
        technique: block.technique,
      };
  }
}
