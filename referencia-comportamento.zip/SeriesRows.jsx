/**
 * SeriesRows
 *
 * Renderiza N séries sequenciais para técnicas simples:
 * work_set, feeder_set, back_off, rest_pause (sem cluster).
 *
 * FLUXO INTERNO:
 *   - Série 1 ativa → aluno preenche peso + reps → toca "Finalizar série 1"
 *   - Série 1 fica done (campos bloqueados)
 *   - Série 2 ativa (se houver)
 *   - Última série concluída → chama onComplete com o record completo
 *
 * O botão de ação fica na ActionBar (via callback/context).
 * Aqui renderizamos um botão inline por simplicidade —
 * adaptar para portal/context se o projeto usar ActionBar centralizada.
 */

import React, { useState } from "react";
import { getActionLabel } from "../utils/actionButtonLabel";

export default function SeriesRows({ block, onComplete }) {
  const totalSeries = block.series ?? 1;

  // Estado de cada série: { weight: string, reps: string, done: boolean }
  const [seriesData, setSeriesData] = useState(() =>
    Array.from({ length: totalSeries }, () => ({
      weight: block.weightSuggested ? String(block.weightSuggested) : "",
      reps: "",
      done: false,
    }))
  );

  // Qual série está ativa agora (0-indexed)
  const activeIndex = seriesData.findIndex((s) => !s.done);
  const allDone = activeIndex === -1;

  function updateField(serieIndex, field, value) {
    setSeriesData((prev) => {
      const next = [...prev];
      next[serieIndex] = { ...next[serieIndex], [field]: value };
      return next;
    });
  }

  function finalizeSerie(serieIndex) {
    const serie = seriesData[serieIndex];

    // Validação: reps obrigatório e > 0
    if (!serie.reps || Number(serie.reps) <= 0) {
      // Sinaliza erro — o input deve acender borda vermelha
      // Implementar via ref ou state local no input
      return false;
    }

    const updated = seriesData.map((s, i) =>
      i === serieIndex ? { ...s, done: true } : s
    );
    setSeriesData(updated);

    const isLast = serieIndex === totalSeries - 1;
    if (isLast) {
      // Constrói o record final e avisa o pai
      onComplete({
        series: updated.map((s) => ({
          weight: Number(s.weight) || 0,
          reps: Number(s.reps),
        })),
      });
    }
    return true;
  }

  return (
    <div className="series-rows">
      {seriesData.map((serie, i) => {
        const isActive = i === activeIndex;
        const isDone = serie.done;
        const isUpcoming = !isActive && !isDone;

        return (
          <div
            key={i}
            className={[
              "series-row",
              isActive && "series-row--active",
              isDone && "series-row--done",
              isUpcoming && "series-row--upcoming",
            ]
              .filter(Boolean)
              .join(" ")}
          >
            <span className="series-row__label">
              Série {i + 1}
            </span>

            {/* Campo peso */}
            <div className="series-row__field">
              <div className="field-label">PESO (KG)</div>
              <input
                className={`field-input ${isDone ? "field-input--done" : ""}`}
                type="number"
                inputMode="decimal"
                placeholder="0"
                value={serie.weight}
                readOnly={isDone || isUpcoming}
                onChange={(e) => updateField(i, "weight", e.target.value)}
              />
            </div>

            {/* Campo reps */}
            <div className="series-row__field">
              <div className="field-label">REPS</div>
              <SeriesRepsInput
                value={serie.reps}
                readOnly={isDone || isUpcoming}
                onChange={(v) => updateField(i, "reps", v)}
              />
            </div>

            {/* Botão de check por série */}
            {isActive && (
              <button
                className={`check-btn ${Number(serie.reps) > 0 ? "check-btn--ready" : ""}`}
                onClick={() => finalizeSerie(i)}
                aria-label={`Finalizar série ${i + 1}`}
              >
                ✓
              </button>
            )}

            {isDone && (
              <span className="check-btn check-btn--checked" aria-label="Concluído">
                ✓
              </span>
            )}
          </div>
        );
      })}

      {/* Botão principal inline — adaptar para ActionBar se necessário */}
      {!allDone && activeIndex >= 0 && (
        <button
          className={`action-btn ${Number(seriesData[activeIndex]?.reps) > 0 ? "" : "action-btn--disabled"}`}
          onClick={() => finalizeSerie(activeIndex)}
        >
          {getActionLabel({
            context: "series",
            serieIndex: activeIndex,
            totalSeries,
            techniqueTitle: block.techniqueTitle,
          })}
        </button>
      )}
    </div>
  );
}

// Input de reps com feedback visual de erro
function SeriesRepsInput({ value, readOnly, onChange }) {
  const [hasError, setHasError] = useState(false);

  function handleBlur() {
    if (value && Number(value) <= 0) {
      setHasError(true);
      setTimeout(() => setHasError(false), 1200);
    }
  }

  return (
    <input
      className={`field-input ${readOnly ? "field-input--done" : ""} ${hasError ? "field-input--error" : ""}`}
      type="number"
      inputMode="numeric"
      placeholder="0"
      value={value}
      readOnly={readOnly}
      onChange={(e) => {
        setHasError(false);
        onChange(e.target.value);
      }}
      onBlur={handleBlur}
    />
  );
}
