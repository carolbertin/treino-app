/**
 * ClusterInput
 *
 * Renderiza a interface de cluster set:
 * N mini-séries lado a lado, com campo de reps individual.
 * Um peso compartilhado entre todas.
 * Timer curto (padrão 7s) inline entre mini-séries.
 *
 * FLUXO:
 *   mini_1_active → aluno registra → mini_1_resting (timer 7s inline)
 *   → mini_2_active → aluno registra → mini_2_resting
 *   → mini_3_active → aluno registra → all_done → onComplete()
 *
 * DIFERENÇA do RestTimer:
 *   O timer do cluster é INLINE (pequeno, dentro do card).
 *   O RestTimer entre blocos é FULLSCREEN.
 */

import React, { useState, useEffect, useRef } from "react";

export default function ClusterInput({ block, onComplete }) {
  const totalMini = block.clusterBlocks ?? 3;
  const repsTarget = block.repsPerCluster ?? 4;
  const restBetween = block.restBetweenClusters ?? 7;

  const [weight, setWeight] = useState(
    block.weightSuggested ? String(block.weightSuggested) : ""
  );
  // Reps de cada mini-série (string para o input)
  const [miniReps, setMiniReps] = useState(() =>
    Array.from({ length: totalMini }, () => String(repsTarget))
  );
  // Qual mini-série está ativa agora (0-indexed). -1 = nenhuma (timer rodando)
  const [activeMini, setActiveMini] = useState(0);
  // Quais mini-séries foram concluídas
  const [doneMinis, setDoneMinis] = useState([]);
  // Timer inline entre mini-séries
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const timerRef = useRef(null);

  // Inicia timer inline entre mini-séries
  function startInlineTimer(afterIndex) {
    setTimerActive(true);
    setTimerSeconds(restBetween);
    setActiveMini(-1); // nenhuma ativa durante o timer

    timerRef.current = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          setTimerActive(false);
          setActiveMini(afterIndex + 1); // ativa a próxima
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  function skipInlineTimer(afterIndex) {
    clearInterval(timerRef.current);
    setTimerActive(false);
    setActiveMini(afterIndex + 1);
    setTimerSeconds(0);
  }

  useEffect(() => {
    return () => clearInterval(timerRef.current); // cleanup
  }, []);

  function registerMini(miniIndex) {
    const reps = Number(miniReps[miniIndex]);
    if (!reps || reps <= 0) return;

    const newDone = [...doneMinis, miniIndex];
    setDoneMinis(newDone);

    const isLast = miniIndex === totalMini - 1;

    if (isLast) {
      // Conclui o bloco inteiro
      onComplete({
        weight: Number(weight) || 0,
        miniSeries: miniReps.map(Number),
      });
    } else {
      startInlineTimer(miniIndex);
    }
  }

  return (
    <div className="cluster-input">
      {/* Campo de peso compartilhado */}
      <div className="cluster-input__weight">
        <div className="field-label">PESO (KG)</div>
        <input
          className="field-input"
          type="number"
          inputMode="decimal"
          placeholder="0"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          style={{ maxWidth: 120 }}
        />
      </div>

      {/* Mini-séries lado a lado */}
      <div className="cluster-input__minis">
        {Array.from({ length: totalMini }, (_, i) => {
          const isActive = activeMini === i;
          const isDone = doneMinis.includes(i);
          const isUpcoming = !isActive && !isDone && activeMini !== -1;

          return (
            <div
              key={i}
              className={[
                "cluster-mini",
                isActive && "cluster-mini--active",
                isDone && "cluster-mini--done",
                isUpcoming && "cluster-mini--upcoming",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              <div className="cluster-mini__label">Mini-série {i + 1}</div>

              {/* Reps — editável apenas quando ativa */}
              {isActive ? (
                <input
                  className="cluster-mini__reps-input"
                  type="number"
                  inputMode="numeric"
                  value={miniReps[i]}
                  onChange={(e) => {
                    const next = [...miniReps];
                    next[i] = e.target.value;
                    setMiniReps(next);
                  }}
                />
              ) : (
                <div
                  className={`cluster-mini__reps-display ${isDone ? "cluster-mini__reps-display--done" : ""}`}
                >
                  {miniReps[i] || repsTarget}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Timer inline entre mini-séries */}
      {timerActive && (
        <div className="cluster-input__inline-timer">
          <span className="cluster-input__timer-count">{timerSeconds}s</span>
          <span className="cluster-input__timer-label">de descanso</span>
          <button
            className="cluster-input__timer-skip"
            onClick={() => skipInlineTimer(doneMinis.length - 1)}
          >
            Pular
          </button>
        </div>
      )}

      {/* Hint de descanso */}
      {!timerActive && activeMini >= 0 && activeMini < totalMini && (
        <div className="cluster-input__rest-hint">
          {restBetween}s de descanso entre mini-séries
        </div>
      )}

      {/* Botão de ação por mini-série */}
      {activeMini >= 0 && activeMini < totalMini && !timerActive && (
        <button
          className={`action-btn ${Number(miniReps[activeMini]) > 0 ? "" : "action-btn--disabled"}`}
          onClick={() => registerMini(activeMini)}
        >
          {activeMini < totalMini - 1
            ? `Registrar mini-série ${activeMini + 1}`
            : "Finalizar cluster"}
        </button>
      )}
    </div>
  );
}
