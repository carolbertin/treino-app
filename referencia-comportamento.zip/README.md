# Referência de implementação — Tela do Aluno

Use estes arquivos como referência de comportamento e estrutura.
Adapte para o seu stack (React Native / Next.js) mantendo a mesma lógica de fluxo.

---

## Estrutura de arquivos

```
components/
  ExerciseScreen.jsx   ← orquestrador principal (estado global, fluxo de blocos)
  BlockCard.jsx        ← renderiza bloco em 3 estados: upcoming / active / done
  SeriesRows.jsx       ← séries simples (work_set, feeder_set, back_off)
  ClusterInput.jsx     ← cluster set com timer inline entre mini-séries
  RestTimer.jsx        ← overlay fullscreen de descanso entre blocos
  ProgressTrack.jsx    ← barra de progresso segmentada

utils/
  techniqueTranslator.js  ← converte técnica do professor → linguagem do aluno
  actionButtonLabel.js    ← label exato do botão por estado

styles/
  exercise.css         ← todos os tokens de cor e estilos dos componentes
```

---

## Princípios que NÃO devem mudar na adaptação

1. **Revelação progressiva** — apenas o bloco ativo está expandido.
   Anteriores colapsam (opacidade 35%). Próximos ficam em preview (opacidade 50%).

2. **Tradução de técnica na camada de apresentação**
   O banco salva "feeder_set". O aluno vê "Aquecimento".
   Toda tradução passa por `techniqueTranslator.js` — não hardcode nos componentes.

3. **Timer fullscreen vs timer inline**
   - `RestTimer` (entre blocos) → fullscreen, substitui a tela
   - Timer do `ClusterInput` (entre mini-séries) → inline, dentro do card

4. **Botão primário sempre descreve a ação exata**
   Nunca "Confirmar" ou "OK". Sempre "Finalizar série 2", "Registrar mini-série 1", etc.
   Gerado por `actionButtonLabel.js`.

5. **Validação silenciosa**
   Reps = 0 → campo pisca vermelho por 1.2s. Sem toast. Sem modal. Sem texto de erro.

6. **Timer usa clock real, não setInterval acumulado**
   Ver `RestTimer.jsx` — usa `Date.now()` como referência para não acumular drift
   quando o app volta do background.

---

## O que adaptar para React Native

| Web (referência) | React Native |
|---|---|
| `position: fixed` no RestTimer | `position: absolute` + `zIndex: 100` dentro de um View que cobre a tela |
| `requestAnimationFrame` no timer | `setInterval` com `AppState` listener para pausar/retomar |
| `navigator.vibrate(200)` | `Vibration.vibrate(200)` do react-native |
| `input type="number"` | `TextInput` com `keyboardType="numeric"` |
| CSS classes | StyleSheet ou Tailwind (expo) |
| `overflow: hidden` no card | `overflow="hidden"` na View |

---

## Fluxo de estados (para implementar como máquina de estados)

```
ExerciseScreen:
  loading → ready → executing → resting → completed → saving → saved

BlockCard (por bloco):
  upcoming → active → done

SeriesRows (interna):
  idle → filling (reps > 0) → done (série N concluída)

ClusterInput (interna):
  mini_N_active → mini_N_resting (timer 7s) → mini_(N+1)_active → ... → all_done

RestTimer:
  hidden → counting → (finished | skipped)
```

---

## Cores principais (tokens)

```
--bg-screen:  #0d0d0d   fundo da tela
--bg-card:    #181818   cards de bloco
--accent:     #c8ff00   cor de ação (botões, progresso, check)
--warm:       #EF9F27   badge de aquecimento (feeder_set)
--cluster:    #5DCAA5   badge e hint do cluster set
```

---

## Como passar dados do professor para a tela

O objeto `block` que cada `BlockCard` recebe vem do banco como configuração do professor.
O `techniqueTranslator` faz o mapeamento. Exemplo:

```js
// O que vem do banco (configurado pelo professor)
const block = {
  id: "b1",
  technique: "feeder_set",
  series: 2,
  repsTarget: 10,
  rir: 2,
  restSeconds: 60,
  weightSuggested: 50,
}

// O que o aluno vê (gerado pelo translator)
const translation = translateTechnique(block)
// → {
//     title: "Aquecimento",
//     subtitle: "2 séries · pare com 2 sobrando",
//     hint: "Série leve de aquecimento. Pare enquanto ainda está fácil...",
//     preview: "Aquecimento · 2 séries",
//     badge: "Aquecimento",
//     badgeVariant: "warm",
//   }
```
