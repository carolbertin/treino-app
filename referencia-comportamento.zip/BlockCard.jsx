/**
 * BlockCard
 *
 * Renderiza um bloco de treino em um de três estados:
 *   - "upcoming"  → preview colapsado, não interativo, opacidade 50%
 *   - "active"    → campos de input visíveis, botão de ação
 *   - "done"      → resumo colapsado, opacidade 35%
 *
 * Delega para subcomponentes por técnica:
 *   - work_set / feeder_set / back_off → SeriesRows (N séries simples)
 *   - cluster_set                       → ClusterInput
 *   - rest_pause                        → RestPauseInput (a implementar)
 */

import React from "react";
import { translateTechnique } from "../utils/techniqueTranslator";
import { getActionLabel } from "../utils/actionButtonLabel";
import SeriesRows from "./SeriesRows";
import ClusterInput from "./ClusterInput";

export default function BlockCard({ block, state, record, index, total, onComplete }) {
  const translation = translateTechnique(block);
  // "active" → dois subestados internos gerenciados por SeriesRows / ClusterInput
  // O BlockCard em si não precisa rastrear isso — cada subcomponente chama onComplete

  const isUpcoming = state === "upcoming";
  const isDone = state === "done";
  const isActive = state === "active";

  return (
    <div
      className={[
        "block-card",
        isUpcoming && "block-card--upcoming",
        isDone && "block-card--done",
        isActive && "block-card--active",
      ]
        .filter(Boolean)
        .join(" ")}
    >
      {/* ── Bloco upcoming: preview de uma linha ── */}
      {isUpcoming && <UpcomingPreview translation={translation} />}

      {/* ── Bloco concluído: header + resumo ── */}
      {isDone && <DoneBlock translation={translation} record={record} index={index} total={total} />}

      {/* ── Bloco ativo: header + inputs + botão ── */}
      {isActive && (
        <ActiveBlock
          block={block}
          translation={translation}
          index={index}
          total={total}
          onComplete={onComplete}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Bloco upcoming — preview não interativo
// ---------------------------------------------------------------------------
function UpcomingPreview({ translation }) {
  return (
    <div className="block-card__upcoming-preview">
      <div className="block-card__upcoming-icon">
        <span>···</span>
      </div>
      <span className="block-card__upcoming-text">
        A seguir: {translation.preview}
      </span>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Bloco done — colapsado com resumo
// ---------------------------------------------------------------------------
function DoneBlock({ translation, record, index, total }) {
  const summary = formatRecord(record, translation.technique);

  return (
    <>
      <div className="block-card__header">
        <div>
          <div className="block-card__step">
            Etapa {index + 1} de {total}
          </div>
          <div className="block-card__title">{translation.title}</div>
          <div className="block-card__subtitle">{translation.subtitle}</div>
        </div>
        <span className="badge badge--done">Concluído</span>
      </div>
      <div className="block-card__done-row">
        <span className="block-card__done-check">✓</span>
        <span className="block-card__done-summary">{summary}</span>
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// Bloco ativo — header + hint + inputs
// ---------------------------------------------------------------------------
function ActiveBlock({ block, translation, index, total, onComplete }) {
  return (
    <>
      {/* Header */}
      <div className="block-card__header">
        <div>
          <div className="block-card__step">
            Etapa {index + 1} de {total} · agora
          </div>
          <div className="block-card__title">{translation.title}</div>
          <div className="block-card__subtitle">{translation.subtitle}</div>
        </div>
        <span className={`badge badge--${translation.badgeVariant}`}>
          {translation.badge}
        </span>
      </div>

      {/* Hint box — instrução de ação */}
      {translation.hint && (
        <div className={`hint-box hint-box--${translation.badgeVariant}`}>
          <p>{translation.hint}</p>
        </div>
      )}

      {/* Inputs por técnica */}
      {block.technique === "cluster_set" ? (
        <ClusterInput block={block} onComplete={onComplete} />
      ) : (
        <SeriesRows block={block} onComplete={onComplete} />
      )}

      {/* Textarea de observações — sempre visível no bloco ativo */}
      <div className="block-card__obs">
        <textarea
          className="obs-input"
          placeholder="Dor, dificuldade…"
          rows={2}
        />
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function formatRecord(record, technique) {
  if (!record) return "—";
  if (technique === "cluster_set") {
    const peso = record.weight ?? 0;
    return record.miniSeries
      .map((r) => `${r} reps`)
      .join(" · ") + ` — ${peso} kg`;
  }
  // Séries simples: "50 kg × 10 · 50 kg × 8"
  return (record.series || [])
    .map((s) => `${s.weight} kg × ${s.reps}`)
    .join(" · ");
}
