/**
 * actionButtonLabel
 *
 * Retorna o label exato do botão primário conforme o estado atual.
 *
 * O botão NUNCA diz apenas "Confirmar" ou "OK".
 * Sempre descreve a ação específica que está acontecendo.
 *
 * Contextos possíveis:
 *   "series"       → dentro de SeriesRows (séries simples)
 *   "cluster_mini" → dentro de ClusterInput (mini-séries)
 *   "save"         → ActionBar após todos os blocos concluídos
 *   "saving"       → durante o request de save
 *
 * Exemplos de output:
 *   "Finalizar série 1"
 *   "Finalizar série 2"
 *   "Concluir aquecimento"       ← última série de um feeder_set
 *   "Registrar mini-série 1"
 *   "Registrar mini-série 2"
 *   "Finalizar cluster"          ← última mini-série
 *   "Salvar exercício"
 *   "Salvando…"
 */

export function getActionLabel({ context, serieIndex, totalSeries, techniqueTitle, miniIndex, totalMinis }) {
  switch (context) {
    case "series": {
      const isLast = serieIndex === totalSeries - 1;
      if (isLast && totalSeries === 1) {
        // Série única — usar nome da técnica como contexto
        return `Concluir ${techniqueTitle?.toLowerCase() ?? "série"}`;
      }
      if (isLast) {
        return `Concluir ${techniqueTitle?.toLowerCase() ?? "série"}`;
      }
      return `Finalizar série ${serieIndex + 1}`;
    }

    case "cluster_mini": {
      const isLast = miniIndex === totalMinis - 1;
      if (isLast) return "Finalizar cluster";
      return `Registrar mini-série ${miniIndex + 1}`;
    }

    case "save":
      return "Salvar exercício";

    case "saving":
      return "Salvando…";

    case "saved":
      return "Salvo!";

    default:
      return "Continuar";
  }
}
